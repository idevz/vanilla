-- Request moudle
-- @since 2017-02-16 00:54
-- @author idevz <zhoujing00k@gmail.com>
-- version $Id$

_VERSION = '0.1.0.rc7'